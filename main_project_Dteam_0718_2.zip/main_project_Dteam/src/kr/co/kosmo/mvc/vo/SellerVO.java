package kr.co.kosmo.mvc.vo;

public class SellerVO {
	
	private int sel_num;
	private String sel_name;
	private String sel_tel;
	private String sel_addr;
	private int sel_grade;
	
	public int getSel_num() {
		return sel_num;
	}
	public void setSel_num(int sel_num) {
		this.sel_num = sel_num;
	}
	public String getSel_name() {
		return sel_name;
	}
	public void setSel_name(String sel_name) {
		this.sel_name = sel_name;
	}
	public String getSel_tel() {
		return sel_tel;
	}
	public void setSel_tel(String sel_tel) {
		this.sel_tel = sel_tel;
	}
	public String getSel_addr() {
		return sel_addr;
	}
	public void setSel_addr(String sel_addr) {
		this.sel_addr = sel_addr;
	}
	public int getSel_grade() {
		return sel_grade;
	}
	public void setSel_grade(int sel_grade) {
		this.sel_grade = sel_grade;
	}
	

}
